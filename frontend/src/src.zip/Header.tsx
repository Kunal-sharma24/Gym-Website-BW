import React from "react";
import ThemeToggle from "./ThemeToggle";

export default function Header({ dark, setDark }: { dark: boolean; setDark: (v: boolean) => void }) {
  return (
    <header className="w-full bg-white dark:bg-black transition-colors duration-500">
      {/* Top bar */}
      <div className="flex justify-between items-center px-6 pt-6 pb-2 max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-black dark:text-white">Fit Me</h1>
        <div className="flex items-center gap-6">
          <nav>
            <ul className="flex gap-6 text-lg font-medium">
              {[
                "Workout Plan",
                "Nutrition",
                "Progress",
                "Testimonials",
                "Mentors",
              ].map((item) => {
                const id = item.toLowerCase().replace(/\s+/g, "");
                return (
                  <li key={id}>
                    <a
                      href={`#${id}`}
                      className="transition-colors duration-300 text-black dark:text-white hover:underline"
                    >
                      {item}
                    </a>
                  </li>
                );
              })}
            </ul>
          </nav>
          <ThemeToggle dark={dark} setDark={setDark} />
        </div>
      </div>
      {/* Hero Section */}
      <section
        className="relative bg-cover bg-center h-[60vh] flex items-center justify-center"
        style={{
          backgroundImage:
            "url('https://media-hosting.imagekit.io/6aa86fee15df4638/d34b7cb07d9e7cb04cee83e6f8728b7e.jpg?Expires=1839671230&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=g69pvbm62HCbc3wtVY541YejPJuifS73WryAwO1yAmKbgkcNECv7g01feshCpfW3cpnjIMUxOPXPHG8l-HxVefXcsSdDx2SueztcN-CxTTXaPNnM7-LqCD-Ua31Gc0ZfTEHcuS8D-NDJnV2mGuMH8u3Fm7twa5RmdgTGUb4sBp3T54JJ3v3LAwVjxdTGH6X1c~-2XS11kJa7ryOZkIMcsCUNdMHXt4OQEmxdt6-88izhKN4tzgk1w3-Z32MpS7E8WJgZxe1SUuwwr2gqlCH7KVJ~dcFIk8NNVrHbSxl07f4hzSN5THo6h~l~WtXMuA~1xEo9q8W1ePlOioYO6AnEjA__')",
        }}
      >
        <div className="bg-white bg-opacity-90 dark:bg-black dark:bg-opacity-80 p-10 rounded-2xl shadow-lg text-center max-w-xl w-full mx-4 border border-neutral-200 dark:border-neutral-700">
          <h2 className="text-4xl font-bold text-black dark:text-white mb-2">FitLife Gym</h2>
          <div className="w-16 h-1 bg-black dark:bg-white mx-auto mb-4 rounded-full" />
          <p className="text-gray-700 dark:text-gray-200 text-lg">
            Transform Your Life, One Workout at a Time
          </p>
        </div>
      </section>
    </header>
  );
}
