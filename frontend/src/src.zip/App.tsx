import React, { useEffect, useState } from "react";
import Header from "./Header";
import WorkoutPlan from "./WorkoutPlan";
import Nutrition from "./Nutrition";
import Progress from "./Progress";
import Testimonials from "./Testimonials";
import Mentors from "./Mentors";
import Footer from "./Footer";

function App() {
  // Dark/light mode state
  const [dark, setDark] = useState(() => {
    const saved = localStorage.getItem("theme");
    return saved ? saved === "dark" : true;
  });
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);

  return (
    <>
    <div className="min-h-screen font-sans bg-white text-black dark:bg-black dark:text-white transition-colors duration-500">
      <Header dark={dark} setDark={setDark} />
      <main>
        <WorkoutPlan />
        <Nutrition />
        <Progress />
        <Testimonials />
        <Mentors />
      </main>
      <Footer />
    </div>
    </>
  );
}

export default App;
